codeDir<-"code"
source(paste(codeDir,"readPara.r",sep="/"))
source(paste(codeDir,"isPeakEx.r",sep="/"))
source(paste(codeDir,"parseFileName.r",sep="/"))
source(paste(codeDir,"GcCompoundAlignment.r",sep="/"))
source(paste(codeDir,"dotprod.r",sep="/"))
source(paste(codeDir,"parDistCal.r",sep="/"))
source(paste(codeDir,"splitEx.r",sep="/"))
source(paste(codeDir,"piplineVisualization.r",sep="/"))
source(paste(codeDir,"libMatching.r",sep="/"))
source(paste(codeDir,"GcPreprocess.r",sep="/"))
source(paste(codeDir,"JavaBioMarkerTable.r",sep="/"))
source(paste(codeDir,"CompoundRedetection.r",sep="/"))
source(paste(codeDir,"BiomarkerTableOutput.r",sep="/"))


	

	












	










	


				







